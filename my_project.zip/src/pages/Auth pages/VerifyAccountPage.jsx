import VerifyAccount from "../../components/verifyAccount/VerifyAccount";

function VerifyAccountPage() {
  return (
    <div>
      <VerifyAccount />
    </div>
  );
}

export default VerifyAccountPage;
