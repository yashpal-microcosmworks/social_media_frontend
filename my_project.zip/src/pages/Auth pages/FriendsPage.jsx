function FriendsPage() {
  return <h1>Friends page</h1>;
}

export default FriendsPage;
